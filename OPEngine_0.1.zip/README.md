# OPEngine - Motor Gráfico

Este paquete contiene una versión distribuible del motor AEngine.

## Configuración

1. Ejecuta tools\gendeps.bat para generar las dependencias.
2. Ejecuta tools\genproject.bat para crear la solución de Visual Studio.

## Documentación

- https://rubich4.github.io/

## Ejemplos incluidos

- BlackWindow: Ventana en negro a modo de ejemplos

## Cosas adicionales

- Skybox day
- Obj y texturas de objeto luffy
- fragment, vertex y geometry

